import React from "react"

function App(props){
    return(
        <div>
            <h3>{props.chat.question}</h3>
            <h4>{props.chat.joke}</h4>
        </div>
    )
}

export default App