import React from "react";
import App from "./App";

function Info()
{
    return(
        <div>
            <App
                chat={{question:"Go to hell", joke:"I am alrady standing with u"}}
            />
            <App
                chat={{question:"Joke achha krta be joker", joke:"M jokta nhi thokta bhi achha h"}}
            />
        </div>
    )
}

export default Info