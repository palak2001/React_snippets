import React from 'react';
import ReactDOM from 'react-dom';
import Info from "./Info";

ReactDOM.render(<Info />,document.getElementById("root"));