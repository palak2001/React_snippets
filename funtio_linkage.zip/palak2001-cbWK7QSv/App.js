import React from "react";
import Para1 from "./para1.js";
import Para2 from "./para2.js";
import Para3 from "./para3.js";

function App()
{
    return(
        <div>
            <Para1 />
            <Para2 />
            <Para3 />
        </div>
    );
}

export default App