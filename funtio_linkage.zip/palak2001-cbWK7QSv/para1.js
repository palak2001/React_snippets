import React from "react"

function para1()
{
    return(
        <p>Hi, I m para 1</p>
    )
}

export default para1