import React from "react"

function para2()
{
    return(
        <p>Hi, I m para 2</p>
    )
}

export default para2