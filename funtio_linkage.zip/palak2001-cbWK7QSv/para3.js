import React from "react"

function para3()
{
    return(
        <p>Hi, I m para 3</p>
    )
}
export default para3